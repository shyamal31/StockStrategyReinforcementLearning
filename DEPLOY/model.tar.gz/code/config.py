config = {
    "total_inventory": 1000,
    "test_size": 0.2,
    "random_state": 42
}
